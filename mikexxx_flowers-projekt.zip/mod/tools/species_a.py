"""1-block European garden flowers."""
from toolkit import *

BLOOM_PLUS = [".H.", "PCP", ".D."]
BLOOM5 = [".HPH.", "HPCPH", ".PDP."]
STAR5 = [".HPH.", "HPSPH", "PSCSP", ".DSD.", "..D.."]
CUP5 = ["P.H.P", "PHPHP", "PPCPD", ".PDD."]
DAISY_S = ["...H...", ".H.P.P.", "..PKP..", "HPKKKPD", "..PKP..", ".P.D.D.", "...D..."]
DAISY_F = ["..HPP..", ".HPPPPD", "HPPKKPP", "PPKkKPD", "PPPKPDD", ".PPDDD.", "..DDD.."]
COSMOS = [".HP.PH.", "HPPPPPD", "PPPCCPP", "PPPCCPD", ".PPPPD.", "..D.D.."]
CONE = ["...kKk...", "..kKCKk..", "HP.kKKk.PH", "PPP.kk.PPD", ".PPD..DPP.", "..PD..DP.."]
PANSY = [".HP.PH.", "HPPHPPD", "PPXCXPD", ".PXCXP.", "..PDP.."]
POPPY = [".HPPH.", "HPPHPD", "PPBBPD", "PPBCBP", ".PPDD."]
ANEMONE = [".HPH.", "HPPPD", "PPBBP", "PPBCP", ".PDD."]
CROCUS = ["..C..", ".HPD.", "HPPPD", "PPPPD", ".PDP."]
BELL = ["P.H.P", "PHPPD", ".PPPD", ".PDD."]

def stems(cv, segs, k='G'):
    for s in segs: cv.ln(*s, k)

def columbine(cv):
    stems(cv, [(8, 6, 8, 15), (8, 13, 3, 10), (8, 12, 13, 10)])
    cv.st(1, 5, STAR5); cv.st(11, 5, STAR5); cv.st(6, 1, STAR5)
    cv.leaf(8, 15, 1, 2); cv.leaf(8, 14, -1, 2); cv.leaf(8, 12, 1, 1)

def forgetmenot(cv):
    stems(cv, [(8, 15, 8, 10), (8, 12, 4, 8), (8, 11, 12, 7), (8, 10, 6, 5), (9, 10, 10, 5)])
    for cx, cy in [(8, 8), (4, 6), (12, 5), (6, 3), (10, 3)]:
        cv.st(cx - 1, cy - 1, BLOOM_PLUS)
    cv.leaf(8, 15, 1, 1); cv.leaf(8, 14, -1, 2); cv.leaf(8, 12, 1, 1)

def pansy(cv):
    stems(cv, [(5, 8, 8, 15), (11, 9, 8, 15)])
    cv.st(2, 3, PANSY); cv.st(8, 5, PANSY)
    cv.leaf(8, 15, 1, 2); cv.leaf(8, 14, -1, 2)

def primrose(cv):
    for bx, by, tx in [(1, 4, 5), (5, 1, 8), (9, 5, 11)]:
        cv.ln(bx + 2, by + 3, tx, 11, 'G')
        cv.st(bx, by, BLOOM5)
    cv.st(2, 11, ["..lLLl....", ".lGGGGl...", "lGGgGgGl.."]) 
    cv.st(6, 11, ["...lLLl..", "..lGGGGl.", ".lGGgGgGl"])
    cv.st(0, 13, [".lLl.", "lGGGl"]); cv.st(11, 13, [".lLl.", "lGGGl"])
    cv.st(2, 14, ["GGgGgGGgGGgGGg"])

def lavender(cv):
    for x, top in [(4, 3), (8, 1), (12, 4)]:
        cv.ln(8, 15, x, top + 6, 'l')
        for j in range(7):
            y = top + j
            w = 0 if j == 0 else 1
            for dx in range(-w, w + 1):
                cv.set(x + dx, y, 'H' if (dx == -1 and j % 2 == 0) else ('D' if (dx == 1 and j % 2) else 'P'))
    for lean, x in [(-3, 6), (3, 10), (-5, 5), (5, 11)]:
        cv.blade(x, 9, 15, lean=lean * 0 + (1 if lean > 0 else -1), k='l')
    cv.blade(8, 10, 15, 0, 'G')

def bellflower(cv):
    stems(cv, [(8, 6, 8, 15), (8, 12, 3, 10), (8, 11, 13, 9)])
    cv.st(6, 2, BELL); cv.st(1, 6, BELL); cv.st(11, 5, BELL)
    cv.ln(3, 9, 3, 10); cv.ln(13, 8, 13, 9)
    cv.leaf(8, 15, 1, 2); cv.leaf(8, 14, -1, 2)

def coneflower(cv):
    cv.stem(8, 7, 15, 1)
    cv.st(3, 1, CONE)
    cv.leaf(8, 15, 1, 3); cv.leaf(8, 13, -1, 2)

def marguerite(cv):
    stems(cv, [(8, 5, 8, 15), (8, 13, 3, 9)])
    cv.st(5, 1, DAISY_S); cv.st(2, 6, [".H.", "PKP", ".D."])
    cv.leaf(8, 15, 1, 2); cv.leaf(8, 14, -1, 2)

def aster(cv):
    stems(cv, [(8, 6, 8, 15), (8, 13, 3, 9)])
    cv.st(5, 0, DAISY_F); cv.st(1, 6, [".HP.", "HPCP", ".PD."])
    cv.leaf(8, 15, 1, 2); cv.leaf(8, 14, -1, 2)

def cosmos(cv):
    stems(cv, [(8, 5, 8, 15), (8, 13, 12, 8)])
    cv.st(5, 0, COSMOS); cv.st(11, 5, [".HP.", "HPCP", ".PD."])
    cv.blade(6, 8, 15, -2, 'l'); cv.blade(10, 9, 15, 2, 'l')
    cv.leaf(8, 15, 1, 1); cv.leaf(8, 14, -1, 1)

def poppy(cv):
    stems(cv, [(8, 6, 8, 15), (8, 12, 3, 9)])
    cv.st(5, 1, POPPY); cv.st(2, 6, [".HP.", "PPBD", ".PD."])
    cv.leaf(8, 15, 1, 2); cv.leaf(8, 14, -1, 2)

def geranium(cv):
    stems(cv, [(4, 6, 6, 12), (11, 4, 9, 12)])
    cv.st(2, 3, STAR5); cv.st(9, 1, STAR5)
    cv.st(0, 11, ["..lLl..", ".lGGGl.", "lGgGgGl"]); cv.st(8, 11, ["..lLl..", ".lGGGl.", "lGgGgGl"])
    cv.st(3, 14, ["GGgGGgGGgGGg"])

def anemone(cv):
    stems(cv, [(8, 6, 8, 15), (8, 12, 3, 9), (8, 11, 13, 8)])
    cv.st(6, 2, ANEMONE); cv.st(1, 6, ANEMONE); cv.st(11, 4, ANEMONE)
    cv.leaf(8, 15, 1, 2); cv.leaf(8, 14, -1, 2)

def crocus(cv):
    for x in (3, 7, 11):
        pass
    cv.st(1, 6, CROCUS); cv.st(6, 3, CROCUS); cv.st(10, 7, CROCUS)
    cv.ln(3, 11, 3, 15); cv.ln(8, 8, 8, 15); cv.ln(12, 12, 12, 15)
    for x, lean in [(1, -1), (5, -1), (6, 0), (10, 1), (14, 1), (9, 0)]:
        cv.blade(x, 9, 15, lean, 'l'); cv.set(x, 11, 'L')

def salvia(cv):
    for x, top in [(5, 2), (11, 1)]:
        cv.ln(8, 15, x, top + 7, 'G')
        for j in range(8):
            y = top + j
            for dx in (-1, 0, 1):
                if j == 0 and dx != 0: continue
                cv.set(x + dx, y, 'D' if (j % 2 and dx == 1) else ('H' if (j % 2 == 0 and dx == -1) else 'P'))
    cv.leaf(8, 15, 1, 3); cv.leaf(8, 14, -1, 3); cv.leaf(8, 11, 1, 2)

A_SPECIES = dict(columbine=columbine, forgetmenot=forgetmenot, pansy=pansy, primrose=primrose,
                 lavender=lavender, bellflower=bellflower, coneflower=coneflower,
                 marguerite=marguerite, aster=aster, cosmos=cosmos, poppy=poppy,
                 geranium=geranium, anemone=anemone, crocus=crocus, salvia=salvia)
