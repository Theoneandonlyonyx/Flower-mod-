"""2- and 3-block garden flowers + exotics."""
from toolkit import *
from species_a import BLOOM_PLUS, BLOOM5, STAR5

def spike(cv, cx, y0, y1, floret, kmax=3, step=2):
    fw, fh = len(floret[0]), len(floret)
    row = 0
    for y in range(y0, y1 + 1, step):
        t = (y - y0) / max(1, y1 - y0)
        k = 1 + round(min(1.0, t * 1.6) * (kmax - 1))
        for i in range(k):
            off = (i - (k - 1) / 2) * 2
            x = int(round(cx + off - fw / 2 + (0.5 if row % 2 else 0)))
            cv.st(x, y, floret)
        row += 1

def base_leaves(cv, size=3, ys=None):
    H = cv.h
    ys = ys or [H - 2, H - 7, H - 12]
    for i, y in enumerate(ys):
        cv.leaf(7, y, -1, size if i != 2 else max(1, size - 1)) if i % 2 == 0 else cv.leaf(8, y, 1, size)
        if i == 0: cv.leaf(8, y - 1, 1, size)
    cv.tuft(8, H - 1)

# ------------------------------------------------------------------ spikes
def delphinium(cv):
    H = cv.h
    cv.stem(7, 3, H - 1, 2)
    spike(cv, 8, 0, H - 15, [".H.", "PHP", ".D."], kmax=3)
    base_leaves(cv, 3)

def foxglove(cv):
    H = cv.h
    cv.stem(7, 2, H - 1, 2)
    y = H - 13; i = 0
    while y > 1:
        small = y < 8
        bell = [".P", "PD"] if small else [".HP.", "PPPD", "PWXD", ".PD."]
        side = 1 if i % 2 == 0 else -1
        w = len(bell[0])
        cv.st(9 if side > 0 else 7 - w, y, bell, mirror=(side < 0))
        y -= 3 if not small else 2; i += 1
    cv.st(7, 0, ["PH"])
    base_leaves(cv, 3)

def lupine(cv):
    H = cv.h
    cv.stem(7, 4, H - 1, 2)
    spike(cv, 8, 0, H - 16, ["HPP", "PDD"], kmax=3, step=2)
    palm = ["l..L..l", ".lLGLl.", "lGGgGGl", ".gGGGg."]
    cv.st(0, H - 9, palm); cv.st(9, H - 12, palm); cv.st(1, H - 15, palm[1:]) if H > 32 else None
    cv.ln(6, H - 7, 4, H - 7, 'G'); cv.ln(9, H - 10, 11, H - 10, 'G')
    cv.tuft(8, H - 1)

def snapdragon(cv):
    H = cv.h
    cv.stem(7, 3, H - 1, 2)
    spike(cv, 8, 0, H - 13, ["HPP", "PPD", "PD."], kmax=2, step=2)
    for y, d in [(H - 3, -1), (H - 6, 1), (H - 9, -1)]:
        cv.leaf(7 if d < 0 else 8, y, d, 2)
    cv.tuft(8, H - 1)

def hollyhock(cv):
    H = cv.h
    cv.stem(7, 3, H - 1, 2)
    y, i = 4, 0
    cup = [".HPH.", "HPPPD", "PPCPD", ".PPD."]
    while y < H - 20:
        side = 1 if i % 2 == 0 else -1
        cv.ln(8 if side > 0 else 7, y + 3, 9 if side > 0 else 6, y + 3, 'G')
        cv.st(9 if side > 0 else 2, y, cup)
        y += 6; i += 1
    cv.st(6, 0, [".P.", "PHP"]); 
    big = ["..lLl..", ".lGGGl.", "lGGgGGl", ".GGgGG.", "..GgG.."]
    for j, yy in enumerate(range(H - 19, H - 4, 6)):
        if j % 2 == 0: cv.st(9, yy, big); cv.ln(8, yy + 4, 9, yy + 4, 'G')
        else: cv.st(0, yy, big); cv.ln(7, yy + 4, 6, yy + 4, 'G')
    cv.st(9, H - 4, big[:4]); cv.st(0, H - 6, big[:4]); cv.tuft(8, H - 1)

def mullein(cv):
    H = cv.h
    cv.stem(7, 2, H - 1, 2)
    for y in range(2, H - 14, 3):
        for x in ((6, 9) if (y // 3) % 2 == 0 else (5, 10, 8)):
            cv.set(x, y, 'P'); cv.set(x + 1, y, 'P'); cv.set(x, y + 1, 'C')
    cv.set(7, 0, 'P'); cv.set(8, 0, 'H')
    big = ["...lLl..", "..lLGGl.", ".lLGGgGl", "lGGgGgG."]
    for j, yy in enumerate(range(H - 13, H - 3, 4)):
        cv.st(9, yy, big) if j % 2 == 0 else cv.st(-1, yy, big, mirror=True)
    cv.st(0, H - 4, ["lLGGGGLl......", ".lGgGGGgGgGGl."]); cv.tuft(8, H - 1)

# ------------------------------------------------------------------ heads
def peony(cv):
    H = cv.h
    big = ["...HPPH...", "..HPPPPD..", ".HPPHHPPD.", "HPPHPPHPPD", "PPHPXXPHPD", "PPPHXCXPPD", ".PPPPPPPD.", "..DDDDDD.."]
    cv.stem(7, 8, H - 1, 2)
    cv.st(3, 1, big)

    for y, d in [(12, 1), (16, -1), (20, 1), (24, -1), (H - 3, 1)]:
        cv.leaf(8 if d > 0 else 7, y, d, 3)
    cv.st(9, 10, [".lLl.", "lGGgl"]); cv.tuft(8, H - 1)

def dahlia(cv):
    H = cv.h
    cx, cy, R = 8, 6, 5.2
    cv.stem(7, 11, H - 1, 2)
    for y in range(cy - 6, cy + 7):
        for x in range(cx - 6, cx + 6):
            dx, dy = x + 0.5 - cx, y + 0.5 - cy
            d = (dx * dx + dy * dy) ** 0.5
            if d > R: continue
            ring = int(d)
            if d < 1.3: k = 'C'
            elif ring % 2 == 1: k = 'H' if (dx + dy) < 0 else 'P'
            else: k = 'P' if (dx + dy) < 1 else 'D'
            if d > R - 1 and dx + dy > 2: k = 'D'
            cv.set(x, y, k)
    for y, d in [(15, 1), (19, -1), (23, 1), (H - 3, -1)]:
        cv.leaf(8 if d > 0 else 7, y, d, 3)
    cv.tuft(8, H - 1)

def iris(cv):
    H = cv.h
    cv.stem(7, 8, H - 1, 2)
    bloom = ["...HPH...", "..HPPPD..", ".HPP.PPD.", "HPPPCPPPD", "PPDPCPDPP", ".PD.C.DP.", "..D.C.D.."]
    cv.st(3, 1, bloom)
    cv.st(0, 9, [".HP.", "PPPD", "PCPD", ".PD."]); cv.ln(3, 13, 6, 15, 'G')
    for x, lean in [(2, -1), (4, -1), (11, 1), (13, 1), (5, 0), (10, 0)]:
        for k in range(2):
            cv.blade(x + k, 14, H - 1, lean, 'G' if k == 0 else 'g')
    cv.tuft(8, H - 1)

def phlox(cv):
    H = cv.h
    cv.stem(7, 8, H - 1, 2)
    for cx, cy in [(8, 2), (5, 4), (11, 4), (8, 5), (3, 7), (13, 7), (6, 8), (10, 8)]:
        cv.st(cx - 1, cy - 1, BLOOM_PLUS)
    for y, d in [(14, 1), (18, -1), (22, 1), (H - 3, -1)]:
        cv.leaf(8 if d > 0 else 7, y, d, 2)
    cv.tuft(8, H - 1)

# ------------------------------------------------------------------ exotics
def orchid(cv):
    ORCH = ["HPP.PPD", "PPPHPPD", ".PPCPD.", "..PCP..", "...D..."]
    cv.ln(8, 12, 8, 9); cv.ln(8, 9, 4, 6); cv.ln(8, 9, 12, 8); cv.ln(4, 6, 8, 3)
    cv.st(1, 3, ORCH); cv.st(9, 5, ORCH); cv.st(5, 0, ORCH[:4])
    cv.st(0, 13, ["...lLl...", ".lGGGGgl.", "lGGgGgGGl"]); cv.st(7, 13, ["..lLl...", ".lGGGGl.", "lGgGGGgl"])

def anthurium(cv):
    SP = ["..HP.PH..", ".HPPPPPD.", "HPPPPPPPD", "PPPPPPPPD", ".PPPPPPD.", "..PPPPD..", "...PPD..."]
    cv.ln(5, 8, 5, 15); cv.ln(11, 9, 11, 15)
    cv.st(1, 1, SP); cv.st(7, 3, ["..HPPH.", ".HPPPPD", "HPPPPPD", ".PPPPD.", "..PPD.."])
    cv.set(5, 5, 'S'); cv.set(5, 4, 'S'); cv.set(5, 3, 'C'); cv.set(11, 6, 'S'); cv.set(11, 5, 'C')
    cv.st(0, 12, ["..lLl..", ".lGGGl.", "lGgGgGl", "GgGGGgG"]); cv.st(9, 12, ["..lLl..", ".lGGGl.", "lGgGgGl", "GgGGGgG"])

def calla(cv):
    CA = ["..HPP..", ".HPPPD.", "HPPPPD.", ".PPPD..", "..PPD.."]
    cv.ln(6, 8, 6, 15); cv.ln(11, 9, 11, 15)
    cv.st(3, 2, CA); cv.st(9, 4, CA[1:])
    cv.set(6, 4, 'C'); cv.set(6, 5, 'C'); cv.set(6, 3, 'c'); cv.set(11, 6, 'C'); cv.set(11, 5, 'c')
    arrow = ["...L...", "..lGl..", ".lGGGl.", "lGGgGGl", "GGgGgGG"]
    cv.st(0, 10, arrow[1:]); cv.st(9, 11, arrow[2:])
    cv.ln(3, 15, 3, 15); cv.ln(6, 15, 6, 12, 'g')

def plumeria(cv):
    PL = [".HPP.", "HPPPD", "PPCPP", "DPPPD", ".DPD."]
    cv.stem(8, 8, 15)
    cv.ln(8, 11, 4, 9); cv.ln(8, 9, 12, 8)
    cv.st(2, 4, PL); cv.st(10, 3, PL)
    cv.st(6, 6, [".HP.", "HPPD", "PPCP", ".DP."])
    cv.st(0, 11, ["...lLL..", "..lGGGGl", ".lGGgGGg"]); cv.st(9, 11, ["..LLl...", "lGGGGl..", "gGGgGGl."])
    cv.leaf(8, 15, -1, 3); cv.leaf(8, 14, 1, 3)

def hibiscus(cv):
    H = cv.h
    HIB = ["..HPPH...", ".HPPPPPD.", "HPPXXPPPD", "PPPXCXPPD", ".PPPXPPD.", "..PPPPD..", "...DDD..."]
    cv.stem(7, 9, H - 1, 2)
    cv.st(3, 2, HIB)
    cv.ln(9, 6, 13, 3, 'C'); cv.set(13, 2, 'c'); cv.set(14, 2, 'C'); cv.set(13, 4, 'C')
    for y, d in [(13, 1), (17, -1), (21, 1), (25, -1), (H - 3, 1)]:
        cv.leaf(8 if d > 0 else 7, y, d, 3)
    cv.tuft(8, H - 1)

def protea(cv):
    H = cv.h
    PR = ["..H.P.H..", ".HPPPPPD.", "HPPSSSPPD", "PPSSWSSPD", "PPSSSSSPD", ".PPSSSPD.", "..PPPPD..", "...DDD..."]
    cv.stem(7, 9, H - 1, 2)
    cv.st(3, 1, PR)
    for i in range(3): cv.set(6 + i * 1, 3 + i % 2, 'X')
    for y, d in [(12, 1), (16, -1), (20, 1), (24, -1), (H - 3, 1)]:
        cv.leaf(8 if d > 0 else 7, y, d, 4 if y > 15 else 3)
    cv.tuft(8, H - 1)

def strelitzia(cv):
    H = cv.h
    cv.stem(7, 6, H - 1, 2)
    cv.st(3, 1, ["..H.H.H...", ".HPHPHPD..", ".PPPPPPD.T", "gGGGGGGGgT", ".gGGGGGg..", "..gGGGg..."])
    for y, d in [(14, 1), (19, -1), (24, 1), (H - 3, -1)]:
        cv.leaf(8 if d > 0 else 7, y, d, 4)
    cv.tuft(8, H - 1)

def ginger(cv):
    H = cv.h
    G = ["...H...", "..HPH..", ".HPPPD.", ".PHPPD.", "HPPHPPD", "PPHPPDD", ".PPDPD.", "..PPD.."]
    cv.stem(7, 9, H - 1, 2)
    cv.st(4, 1, G)
    for x in (5, 6, 9, 10): cv.set(x, 5 + (x % 2), 'W')
    for y, d in [(13, 1), (17, -1), (21, 1), (25, -1), (H - 3, 1)]:
        cv.leaf(8 if d > 0 else 7, y, d, 4)
    cv.tuft(8, H - 1)

def heliconia(cv):
    H = cv.h
    cv.stem(7, 2, H - 1, 2)
    BR = ["HPP...", ".PPPC.", "..DPPC"]
    y, i = 1, 0
    while y < H - 19:
        if i % 2 == 0: cv.st(9, y, BR)
        else: cv.st(1, y, BR, mirror=True)
        y += 4; i += 1
    big = ["....lLl.", "...lGGGl", "..lGGgGg", ".lGGgGgG", "lGGgGgg."]
    for j, yy in enumerate(range(H - 17, H - 3, 5)):
        if j % 2 == 0: cv.st(9, yy, big)
        else: cv.st(-1, yy, big, mirror=True)
    cv.tuft(8, H - 1)

B_SPECIES = dict(delphinium=delphinium, foxglove=foxglove, lupine=lupine, snapdragon=snapdragon,
                 hollyhock=hollyhock, mullein=mullein, peony=peony, dahlia=dahlia, iris=iris, phlox=phlox,
                 orchid=orchid, anthurium=anthurium, calla=calla, plumeria=plumeria, hibiscus=hibiscus,
                 protea=protea, strelitzia=strelitzia, ginger=ginger, heliconia=heliconia)
