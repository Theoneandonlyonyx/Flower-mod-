#!/usr/bin/env python3
"""Generates ALL assets + FlowerList.java for Mikexxx flowers. Run: python3 tools/build_assets.py"""
import os, sys, json, shutil
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from toolkit import *
from species_a import A_SPECIES
from species_b import B_SPECIES
from PIL import Image

ROOT = os.path.dirname(HERE)
MODID = 'mikexxx_flowers'
RES = os.path.join(ROOT, 'src/main/resources')
ASSETS = os.path.join(RES, 'assets', MODID); DATA = os.path.join(RES, 'data', MODID)
JAVA = os.path.join(ROOT, 'src/main/java/com/mikexxx/flowers/FlowerList.java')

COLORS = {  # key: (rgb, de, declinable, en)
    'blue': ((62, 100, 222), 'blau', True, 'Blue'), 'light_blue': ((122, 180, 244), 'hellblau', True, 'Light Blue'),
    'purple': ((136, 72, 200), 'violett', True, 'Purple'), 'pink': ((242, 144, 192), 'rosa', False, 'Pink'),
    'magenta': ((208, 52, 152), 'magenta', False, 'Magenta'), 'red': ((206, 38, 48), 'rot', True, 'Red'),
    'orange': ((242, 134, 30), 'orange', False, 'Orange'), 'yellow': ((248, 208, 50), 'gelb', True, 'Yellow'),
    'white': ((244, 244, 238), 'weiß', True, 'White')}
END = {'m': 'er', 'f': 'e', 'n': 'es'}
ALL = {**A_SPECIES, **B_SPECIES}

# key, drawfn, blocks, de, gender, en, colours, group
S = [
 ('columbine','columbine',1,'Akelei','f','Columbine',['blue','purple','pink','red','white','yellow'],'euro'),
 ('forgetmenot','forgetmenot',1,'Vergissmeinnicht','n','Forget-me-not',['blue','pink','white'],'euro'),
 ('pansy','pansy',1,'Stiefmütterchen','n','Pansy',['purple','yellow','blue','orange'],'euro'),
 ('primrose','primrose',1,'Primel','f','Primrose',['yellow','pink','red','blue'],'euro'),
 ('lavender','lavender',1,'Lavendel','m','Lavender',['purple','blue','pink','white'],'euro'),
 ('bellflower','bellflower',1,'Glockenblume','f','Bellflower',['blue','purple','white','pink'],'euro'),
 ('coneflower','coneflower',1,'Sonnenhut','m','Coneflower',['purple','orange','yellow','white'],'euro'),
 ('marguerite','marguerite',1,'Margerite','f','Marguerite',['white','yellow','pink'],'euro'),
 ('aster','aster',1,'Aster','f','Aster',['purple','pink','blue','red'],'euro'),
 ('cosmos','cosmos',1,'Kosmee','f','Cosmos',['pink','white','orange','magenta'],'euro'),
 ('poppy','poppy',1,'Mohn','m','Poppy',['red','orange','pink','white'],'euro'),
 ('geranium','geranium',1,'Storchschnabel','m','Cranesbill',['blue','pink','purple','white'],'euro'),
 ('anemone','anemone',1,'Anemone','f','Anemone',['white','blue','pink','red'],'euro'),
 ('crocus','crocus',1,'Krokus','m','Crocus',['purple','yellow','white'],'euro'),
 ('salvia','salvia',1,'Salbei','m','Sage',['blue','red','purple'],'euro'),
 ('delphinium','delphinium',2,'Rittersporn','m','Delphinium',['blue','light_blue','purple','pink','white'],'euro'),
 ('foxglove','foxglove',2,'Fingerhut','m','Foxglove',['purple','pink','white','yellow'],'euro'),
 ('lupine','lupine',2,'Lupine','f','Lupine',['blue','purple','pink','yellow','white'],'euro'),
 ('snapdragon','snapdragon',2,'Löwenmäulchen','n','Snapdragon',['red','yellow','pink','white','orange'],'euro'),
 ('peony','peony',2,'Pfingstrose','f','Peony',['pink','red','white','magenta'],'euro'),
 ('dahlia','dahlia',2,'Dahlie','f','Dahlia',['red','orange','yellow','pink','purple'],'euro'),
 ('iris','iris',2,'Schwertlilie','f','Iris',['purple','blue','yellow','white'],'euro'),
 ('phlox','phlox',2,'Phlox','m','Phlox',['pink','purple','white','red'],'euro'),
 ('delphinium_giant','delphinium',3,'Riesen-Rittersporn','m','Giant Delphinium',['blue','purple','white','pink'],'euro'),
 ('foxglove_giant','foxglove',3,'Riesen-Fingerhut','m','Giant Foxglove',['purple','pink','white'],'euro'),
 ('lupine_giant','lupine',3,'Riesen-Lupine','f','Giant Lupine',['blue','purple','pink','yellow'],'euro'),
 ('hollyhock','hollyhock',3,'Stockrose','f','Hollyhock',['pink','red','yellow','white','purple'],'euro'),
 ('mullein','mullein',3,'Königskerze','f','Mullein',['yellow'],'euro'),
 ('orchid','orchid',1,'Orchidee','f','Orchid',['pink','white','purple','yellow'],'exotic'),
 ('anthurium','anthurium',1,'Anthurie','f','Anthurium',['red','pink','white'],'exotic'),
 ('calla','calla',1,'Calla','f','Calla Lily',['white','yellow','purple','pink'],'exotic'),
 ('plumeria','plumeria',1,'Frangipani','m','Plumeria',['white','pink','yellow'],'exotic'),
 ('hibiscus','hibiscus',2,'Hibiskus','m','Hibiscus',['red','yellow','pink','orange','white'],'exotic'),
 ('protea','protea',2,'Protea','f','Protea',['pink','white','red'],'exotic'),
 ('strelitzia','strelitzia',2,'Strelitzie','f','Bird of Paradise',['orange','white'],'exotic'),
 ('ginger','ginger',2,'Fackelingwer','m','Torch Ginger',['red','pink'],'exotic'),
 ('heliconia','heliconia',3,'Heliconie','f','Heliconia',['red','yellow','orange'],'exotic'),
]

def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f: f.write(text)
def wj(path, obj): w(path, json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def main():
    for d in (os.path.join(ASSETS), os.path.join(DATA), os.path.join(RES, 'data/minecraft')):
        shutil.rmtree(d, ignore_errors=True)
    lang_en = {f'itemGroup.{MODID}': 'Mikexxx flowers'}
    lang_de = {f'itemGroup.{MODID}': 'Mikexxx flowers'}
    lists = {1: [], 2: [], 3: []}; sheet_cards = []
    for key, fn, n, de, g, en, cols, grp in S:
        tiles = []
        for c in cols:
            name = f'{key}_{c}'; reg = f'{name}.flower'; lists[n].append(name)
            cv = Cv(n, make_pal(COLORS[c][0])); ALL[fn](cv); img = cv.image(); tiles.append(img)
            tex = f'{MODID}:block/{name}'
            if n == 1:
                os.makedirs(os.path.join(ASSETS, 'textures/block'), exist_ok=True); img.save(os.path.join(ASSETS, 'textures/block', name + '.png'))
                wj(f'{ASSETS}/blockstates/{reg}.json', {'variants': {'': {'model': tex}}})
                wj(f'{ASSETS}/models/block/{name}.json', {'parent': 'minecraft:block/cross', 'render_type': 'minecraft:cutout', 'textures': {'cross': tex}})
                wj(f'{ASSETS}/models/item/{reg}.json', {'parent': 'minecraft:item/generated', 'textures': {'layer0': tex}})
            else:
                os.makedirs(os.path.join(ASSETS, 'textures/item'), exist_ok=True)
                os.makedirs(os.path.join(ASSETS, 'textures/block'), exist_ok=True)
                var = {}
                for i in range(n):   # part 0 = bottom
                    piece = img.crop((0, (n - 1 - i) * 16, 16, (n - i) * 16))
                    piece.save(os.path.join(ASSETS, 'textures/block', f'{name}_{i}.png'))
                    wj(f'{ASSETS}/models/block/{name}_{i}.json', {'parent': 'minecraft:block/cross', 'render_type': 'minecraft:cutout', 'textures': {'cross': f'{tex}_{i}'}})
                    var[f'part={i}'] = {'model': f'{tex}_{i}'}
                img.crop((0, 0, 16, 16)).save(os.path.join(ASSETS, 'textures/item', name + '.png'))
                wj(f'{ASSETS}/blockstates/{reg}.json', {'variants': var})
                wj(f'{ASSETS}/models/item/{reg}.json', {'parent': 'minecraft:item/generated', 'textures': {'layer0': f'{MODID}:item/{name}'}})
            cond = [{'condition': 'minecraft:survives_explosion'}]
            if n > 1:
                cond.insert(0, {'condition': 'minecraft:block_state_property', 'block': f'{MODID}:{reg}', 'properties': {'part': '0'}})
            wj(f'{DATA}/loot_tables/blocks/{reg}.json', {'type': 'minecraft:block', 'pools': [{'rolls': 1.0, 'bonus_rolls': 0.0,
               'entries': [{'type': 'minecraft:item', 'name': f'{MODID}:{reg}'}], 'conditions': cond}]})
            adj = COLORS[c][1] + (END[g] if COLORS[c][2] else '')
            lang_en[f'block.{MODID}.{reg}'] = f'{COLORS[c][3]} {en}'
            lang_de[f'block.{MODID}.{reg}'] = f'{adj.capitalize()} {de}'
        sheet_cards.append((tiles, n))
    wj(f'{ASSETS}/lang/en_us.json', dict(sorted(lang_en.items())))
    wj(f'{ASSETS}/lang/de_de.json', dict(sorted(lang_de.items())))
    # vanilla tags (bees, etc.)
    def ids(ns): return [f'{MODID}:{x}.flower' for l in ns for x in lists[l]]
    for kind in ('blocks', 'items'):
        wj(f'{RES}/data/minecraft/tags/{kind}/flowers.json', {'replace': False, 'values': ids([1, 2, 3])})
        wj(f'{RES}/data/minecraft/tags/{kind}/small_flowers.json', {'replace': False, 'values': ids([1])})
        wj(f'{RES}/data/minecraft/tags/{kind}/tall_flowers.json', {'replace': False, 'values': ids([2, 3])})
    # Java list
    def arr(l): return ',\n        '.join('"%s"' % x for x in l)
    w(JAVA, f'''package com.mikexxx.flowers;

/** GENERATED by tools/build_assets.py - do not edit by hand. Names WITHOUT the ".flower" suffix. */
public final class FlowerList {{
    private FlowerList() {{}}

    public static final String[] SINGLE = {{
        {arr(lists[1])}
    }};

    public static final String[] DOUBLE = {{
        {arr(lists[2])}
    }};

    public static final String[] TRIPLE = {{
        {arr(lists[3])}
    }};
}}
''')
    # preview sheet
    sc, gap, maxw = 3, 10, 1180
    cards = []
    for tiles, n in sheet_cards:
        cw = len(tiles) * 18 * sc; ch = n * 16 * sc + 6
        im = Image.new('RGBA', (cw, ch), (0, 0, 0, 0))
        for i, t in enumerate(tiles):
            im.alpha_composite(t.resize((16 * sc, n * 16 * sc), Image.NEAREST), (i * 18 * sc + 3, 3))
        cards.append(im)
    x = y = rowh = 0; placed = []
    for im in cards:
        if x + im.width > maxw: x = 0; y += rowh + gap; rowh = 0
        placed.append((im, x, y)); x += im.width + gap; rowh = max(rowh, im.height)
    sheet = Image.new('RGBA', (maxw, y + rowh + gap), (52, 70, 60, 255))
    for im, px_, py_ in placed: sheet.alpha_composite(im, (px_, py_))
    sheet.save(os.path.join(ROOT, 'preview.png'))
    print({k: len(v) for k, v in lists.items()}, 'total', sum(len(v) for v in lists.values()))

if __name__ == '__main__':
    main()
