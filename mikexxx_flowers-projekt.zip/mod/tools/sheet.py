import sys
sys.path.insert(0, '/home/claude/mod/tools')
from toolkit import *
from PIL import Image, ImageDraw

BASES = {'blue': (62,100,222), 'light_blue': (122,180,244), 'purple': (136,72,200), 'pink': (242,144,192),
         'magenta': (208,52,152), 'red': (206,38,48), 'orange': (242,134,30), 'yellow': (248,208,50), 'white': (244,244,238)}

def render(fn, n, colors, scale=6):
    tiles = []
    for c in colors:
        cv = Cv(n, make_pal(BASES[c])); fn(cv); tiles.append(cv.image())
    W = len(tiles) * (16 + 2) * scale; H = n * 16 * scale + 2 * scale
    sheet = Image.new('RGBA', (W, H), (52, 70, 60, 255))
    for i, t in enumerate(tiles):
        big = t.resize((16 * scale, n * 16 * scale), Image.NEAREST)
        sheet.alpha_composite(big, (i * 18 * scale + scale, scale))
    return sheet
