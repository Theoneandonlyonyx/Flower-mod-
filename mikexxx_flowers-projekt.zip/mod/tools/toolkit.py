"""Pixel-art toolkit: 16x16 tiles, clean 3-tone shading, transparent background."""
from PIL import Image

def mix(a, b, t):
    return tuple(int(round(x + (y - x) * t)) for x, y in zip(a, b))

GREENS = dict(g=(30, 78, 36), G=(50, 122, 44), l=(88, 166, 60), L=(138, 204, 88))

def make_pal(base):
    white = base[0] > 235 and base[1] > 235
    yellowish = base[0] > 220 and base[1] > 180 and base[2] < 110
    pal = dict(GREENS)
    if white:
        pal.update(H=(255, 255, 255), P=(240, 240, 236), D=(196, 200, 226), X=(146, 150, 188))
    else:
        pal.update(H=mix(base, (255, 255, 255), 0.40), P=base,
                   D=mix(base, (20, 0, 40), 0.30), X=mix(base, (20, 0, 40), 0.55))
    C = (214, 116, 22) if yellowish else (252, 214, 70)
    pal.update(C=C, c=mix(C, (60, 20, 0), 0.40))
    pal['S'] = (250, 246, 236) if not white else (252, 232, 130)   # inner / second colour
    pal['s'] = mix(pal['S'], (90, 70, 110), 0.25)
    pal['K'] = (196, 104, 30); pal['k'] = (128, 62, 22)             # cone / brown
    pal['W'] = (255, 255, 250); pal['w'] = (206, 208, 224)
    pal['B'] = (70, 60, 40)
    pal['T'] = (52, 92, 214)
    return pal

class Cv:
    def __init__(self, n, pal):
        self.n, self.w, self.h, self.pal, self.px = n, 16, 16 * n, pal, {}
    def set(self, x, y, k):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.px[(x, y)] = self.pal[k] if isinstance(k, str) else k
    def st(self, x, y, rows, mirror=False):
        for j, row in enumerate(rows):
            if mirror: row = row[::-1]
            for i, ch in enumerate(row):
                if ch not in '. ':
                    self.set(x + i, y + j, ch)
    def ln(self, x0, y0, x1, y1, k='G'):
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx + dy
        while True:
            self.set(x0, y0, k)
            if (x0, y0) == (x1, y1): break
            e2 = 2 * err
            if e2 >= dy: err += dy; x0 += sx
            if e2 <= dx: err += dx; y0 += sy
    def stem(self, x, y0, y1, w=1):
        for y in range(y0, y1 + 1):
            self.set(x, y, 'G')
            if w == 2: self.set(x + 1, y, 'g')
    def leaf(self, x, y, d, size=2):
        """leaf whose base touches (x,y); d=+1 right, -1 left; grows upward."""
        L = {1: [".lL", "Gl."],
             2: ["..lL", ".lGl", "GGg."],
             3: ["...lL", "..lGl", ".lGGg", "GGgg."],
             4: ["....lL", "...lGl", "..lGGl", ".lGGgg", "GGggg."]}[size]
        h = len(L)
        self.st(x + (1 if d > 0 else -len(L[0])), y - h + 1, L, mirror=(d < 0))
    def tuft(self, cx, yb, spread=3):
        rows = [".l.G.l.", "lG.G.Gl", "GGgGgGG"] if spread == 3 else [".l.G.l.", "lGlGlGl", "GGgGgGG"]
        self.st(cx - 3, yb - len(rows) + 1, rows)
    def blade(self, x, y0, y1, lean=0, k='G'):
        n = max(1, y1 - y0)
        for i in range(n + 1):
            self.set(x + round(lean * i / n), y1 - i, k)
    def image(self):
        im = Image.new('RGBA', (self.w, self.h), (0, 0, 0, 0))
        for (x, y), c in self.px.items():
            im.putpixel((x, y), c + (255,))
        return im
