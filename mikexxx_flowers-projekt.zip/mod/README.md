# Mikexxx flowers (Forge 1.20.1)

140 dekorative Blumen: 72x 1 Block, 48x 2 Block, 20x 3 Block (Europaeische Gartenblumen + Exoten).
Alle Registry-IDs enden auf `.flower`, z. B. `mikexxx_flowers:delphinium_blue.flower`.
Kreativtab: "Mikexxx flowers". Keine Weltgenerierung (rein Deko), Blumen sind kompostierbar und in den Tags `minecraft:flowers` / `small_flowers` / `tall_flowers`.

## Jar bauen
Voraussetzung: JDK 17 und Gradle 8.1.1 (oder `gradle wrapper --gradle-version 8.1.1` einmalig ausfuehren).

    gradle build

Das Jar liegt danach in `build/libs/mikexxx_flowers-1.0.0.jar` -> in den `mods`-Ordner (Forge 1.20.1, 47.x).

Ohne lokale Installation: Ordner in ein GitHub-Repo pushen -> Tab "Actions" -> "build-jar" -> Artifact `mikexxx_flowers-jar`.

## Texturen neu erzeugen
    python3 tools/build_assets.py     (benoetigt Pillow)
Erzeugt alle 16x16-Texturen, Blockstates, Modelle, Loot-Tabellen, Lang-Dateien, Tags und `FlowerList.java`.
