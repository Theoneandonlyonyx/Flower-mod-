package com.mikexxx.flowers;

import java.util.LinkedHashMap;
import java.util.Map;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MikexxxFlowers.MODID);

    public static final Map<String, RegistryObject<Item>> FLOWER_ITEMS = new LinkedHashMap<>();

    static {
        ModBlocks.FLOWERS.forEach((name, block) ->
                FLOWER_ITEMS.put(name, ITEMS.register(name + ".flower",
                        () -> new BlockItem(block.get(), new Item.Properties()))));
    }
}
