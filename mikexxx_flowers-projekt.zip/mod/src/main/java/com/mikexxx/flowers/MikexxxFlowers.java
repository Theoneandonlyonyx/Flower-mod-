package com.mikexxx.flowers;

import net.minecraft.world.level.block.ComposterBlock;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MikexxxFlowers.MODID)
public class MikexxxFlowers {
    public static final String MODID = "mikexxx_flowers";

    public MikexxxFlowers() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModTabs.TABS.register(bus);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        // all flowers are compostable
        event.enqueueWork(() -> ModItems.FLOWER_ITEMS.values()
                .forEach(item -> ComposterBlock.COMPOSTABLES.put(item.get(), 0.65F)));
    }
}
