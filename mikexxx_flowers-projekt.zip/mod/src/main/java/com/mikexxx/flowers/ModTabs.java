package com.mikexxx.flowers;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    private ModTabs() {}

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MikexxxFlowers.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("flowers", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MikexxxFlowers.MODID))
                    .icon(() -> new ItemStack(ModItems.FLOWER_ITEMS.get("delphinium_blue").get()))
                    .displayItems((params, output) ->
                            ModItems.FLOWER_ITEMS.values().forEach(item -> output.accept(item.get())))
                    .build());
}
