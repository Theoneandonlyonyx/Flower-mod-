package com.mikexxx.flowers;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    private ModBlocks() {}

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MikexxxFlowers.MODID);

    /** name (without ".flower") -> block. Registry id is name + ".flower". */
    public static final Map<String, RegistryObject<Block>> FLOWERS = new LinkedHashMap<>();

    static {
        for (String n : FlowerList.SINGLE) add(n, () -> new SmallFlowerBlock(props()));
        for (String n : FlowerList.DOUBLE) add(n, () -> new MultiPlantBlock(props(), 2));
        for (String n : FlowerList.TRIPLE) add(n, () -> new MultiPlantBlock(props(), 3));
    }

    private static void add(String name, Supplier<Block> factory) {
        FLOWERS.put(name, BLOCKS.register(name + ".flower", factory));
    }

    private static BlockBehaviour.Properties props() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.PLANT)
                .noCollission()
                .instabreak()
                .sound(SoundType.GRASS)
                .offsetType(BlockBehaviour.OffsetType.XZ)
                .pushReaction(PushReaction.DESTROY);
    }
}
